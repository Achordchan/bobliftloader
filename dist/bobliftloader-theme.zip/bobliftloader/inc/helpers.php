<?php
declare(strict_types=1);

function bl_is_wordpress(): bool
{
    return defined('ABSPATH') && function_exists('home_url');
}

function bl_asset(string $path): string
{
    $base = bl_is_wordpress() ? get_template_directory_uri() . '/assets/' : '/assets/';
    return $base . ltrim($path, '/');
}

function bl_url(string $path = '/'): string
{
    return bl_is_wordpress() ? home_url('/' . ltrim($path, '/')) : '/' . ltrim($path, '/');
}

function bl_escape(string $text): string
{
    return htmlspecialchars($text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function bl_icon(string $name, string $class = ''): string
{
    return '<img class="bl-icon ' . bl_escape($class) . '" src="' . bl_escape(bl_asset('icons/' . $name . '.svg')) . '" alt="" width="24" height="24" aria-hidden="true">';
}

function bl_query(string $key, string $default = ''): string
{
    return isset($_GET[$key]) && is_string($_GET[$key]) ? trim(substr($_GET[$key], 0, 200)) : $default;
}

function bl_read_data(string $file): array
{
    $data = json_decode((string) file_get_contents(__DIR__ . '/data/' . $file . '.json'), true);
    return is_array($data) ? $data : [];
}

function bl_products(): array
{
    if (bl_is_wordpress()) {
        return bl_wp_products();
    }
    $products = bl_read_data('products');
    foreach ($products as &$product) {
        $product['image'] = bl_asset($product['image']);
        $product['excerpt'] = $product['category'] === 'mini-dumpers'
            ? $product['name'] . ' with a ' . $product['capacity'] . ' m³ bucket and ' . $product['power'] . ' kW engine. Explore published specifications and discuss your application with BOB-LIFT.'
            : 'Explore the BOB-LIFT ' . $product['model'] . ' mini skid steer loader. View original product photography and discuss the configuration for your next project.';
        $product['gallery'] = array_map('bl_asset', $product['gallery'] ?? []);
    }
    unset($product);
    return $products;
}

function bl_articles(): array
{
    if (bl_is_wordpress()) {
        return bl_wp_articles();
    }
    $articles = bl_read_data('news');
    foreach ($articles as &$article) {
        $article['image'] = bl_asset($article['image']);
    }
    unset($article);
    return $articles;
}

function bl_find_record(array $records, string $slug): ?array
{
    foreach ($records as $record) {
        if ($record['slug'] === $slug) {
            return $record;
        }
    }
    return null;
}

function bl_product_url(array $product): string
{
    return $product['url'] ?? bl_url('/product/' . $product['slug'] . '/');
}

function bl_article_url(array $article): string
{
    return $article['url'] ?? bl_url('/news/' . $article['slug'] . '/');
}

function bl_contact_url(?array $product = null, string $application = ''): string
{
    $query = [];
    if ($product) $query['product'] = $product['slug'];
    if ($application !== '') $query['application'] = $application;
    return bl_url('/contact/') . ($query ? '?' . http_build_query($query) : '') . '#enquiry';
}

function bl_breadcrumbs(array $items): void
{
    echo '<nav class="bl-breadcrumbs" aria-label="Breadcrumb"><ol><li><a href="' . bl_escape(bl_url('/')) . '">Home</a></li>';
    foreach ($items as $item) {
        echo '<li>' . (isset($item['url']) ? '<a href="' . bl_escape($item['url']) . '">' . bl_escape($item['label']) . '</a>' : '<span aria-current="page">' . bl_escape($item['label']) . '</span>') . '</li>';
    }
    echo '</ol></nav>';
}

function bl_product_card(array $product): void
{
    require __DIR__ . '/../templates/partials/product-card.php';
}

function bl_news_card(array $article): void
{
    require __DIR__ . '/../templates/partials/news-card.php';
}

function bl_application_slug(array $application): string
{
    return strtolower(str_replace(' ', '-', $application['title']));
}
