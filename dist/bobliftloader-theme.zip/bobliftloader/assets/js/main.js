import { initializeDialogs } from './dialogs.js';
import { initializeEquipment, scrollBehavior } from './equipment.js';
import { initializeInquiry } from './inquiry.js';

initializeDialogs();
initializeEquipment();
initializeInquiry();

const menuToggle = document.querySelector('.bl-menu-toggle');
const navigation = document.querySelector('.bl-nav');
const header = document.querySelector('.bl-header');

function closeNavigation(returnFocus = false) {
  menuToggle.setAttribute('aria-expanded', 'false');
  menuToggle.setAttribute('aria-label', 'Open navigation');
  navigation.classList.remove('bl-open');
  if (returnFocus) menuToggle.focus();
}

menuToggle.addEventListener('click', () => {
  const open = menuToggle.getAttribute('aria-expanded') !== 'true';
  menuToggle.setAttribute('aria-expanded', String(open));
  menuToggle.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
  navigation.classList.toggle('bl-open', open);
});

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && menuToggle.getAttribute('aria-expanded') === 'true') closeNavigation(true);
});
document.addEventListener('click', (event) => {
  if (!header.contains(event.target)) closeNavigation();
});
document.addEventListener('focusin', (event) => {
  if (!header.contains(event.target)) closeNavigation();
});
window.matchMedia('(min-width: 601px)').addEventListener('change', () => closeNavigation());

document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener('click', (event) => {
    const target = document.getElementById(anchor.getAttribute('href').slice(1));
    if (!target) return;
    event.preventDefault();
    closeNavigation();
    if (target.id === 'top') {
      window.scrollTo({ top: 0, behavior: scrollBehavior() });
    } else {
      target.scrollIntoView({ behavior: scrollBehavior(), block: 'start' });
    }
    // Move keyboard context with same-page navigation without moving the viewport again.
    if (!target.hasAttribute('tabindex')) target.setAttribute('tabindex', '-1');
    target.focus({ preventScroll: true });
  });
});

const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
const reveals = [...document.querySelectorAll('.bl-reveal')];
let revealObserver;
function setMotionPreference() {
  revealObserver?.disconnect();
  document.body.classList.toggle('bl-motion', !reducedMotion.matches);
  if (reducedMotion.matches) return;
  revealObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      entry.target.classList.add('bl-visible');
      revealObserver.unobserve(entry.target);
    });
  }, { threshold: 0.08, rootMargin: '0px 0px 20px 0px' });
  reveals.forEach((element) => revealObserver.observe(element));
}
setMotionPreference();
reducedMotion.addEventListener('change', setMotionPreference);

let scheduled = false;
window.addEventListener('scroll', () => {
  if (scheduled) return;
  scheduled = true;
  requestAnimationFrame(() => {
    header.classList.toggle('bl-scrolled', window.scrollY > 30);
    scheduled = false;
  });
}, { passive: true });

// The three support topics form one disclosure group, retaining native keyboard behavior.
document.querySelectorAll('.bl-accordions details').forEach((detail) => {
  detail.addEventListener('toggle', () => {
    if (!detail.open) return;
    document.querySelectorAll('.bl-accordions details').forEach((other) => {
      if (other !== detail) other.open = false;
    });
  });
});
