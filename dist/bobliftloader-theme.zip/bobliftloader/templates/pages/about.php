<?php
/** Company facts transcribed from www.boblift.com (About BOB-LIFT, homepage) on 2026-09-20. Keep figures in sync with the main site. */
$companyFacts = [
    ['value' => '37,000', 'unit' => 'm²', 'label' => 'Factory area in Xuzhou, Jiangsu'],
    ['value' => '200', 'unit' => '+', 'label' => 'Countries and regions served'],
    ['value' => 'ISO 9001', 'unit' => '', 'label' => 'Quality system · CE · EAC certified'],
    ['value' => 'IT · SE', 'unit' => '', 'label' => 'Technical cooperation with Italian and Swedish crane makers'],
];
$certificates = [
    ['file' => 'cert-iso9001', 'label' => 'ISO 9001 quality management'],
    ['file' => 'cert-ce-1', 'label' => 'CE certification'],
    ['file' => 'cert-ce-2', 'label' => 'CE certification'],
    ['file' => 'cert-eac', 'label' => 'EAC certification'],
    ['file' => 'cert-type-test', 'label' => 'Truck-mounted crane type-test manufacturing license'],
];
$sites = [
    ['index' => '01', 'eyebrow' => 'MAIN COMPANY WEBSITE', 'title' => 'BOB-LIFT', 'text' => 'Company profile, manufacturing background, certificates and the full product portfolio.', 'domain' => 'boblift.com', 'url' => 'https://www.boblift.com/'],
    ['index' => '02', 'eyebrow' => 'LIFTING EQUIPMENT', 'title' => 'BOB-LIFT<br>CRANE', 'text' => 'SQ08–SQ55 truck-mounted cranes, marine cranes, pickup cranes and related lifting equipment.', 'domain' => 'bobliftcrane.com', 'url' => 'https://www.bobliftcrane.com/'],
    ['index' => '03', 'eyebrow' => 'COMPACT EQUIPMENT', 'title' => 'BOB-LIFT<br>COMPACT EQUIPMENT', 'text' => 'Skid steer loaders, mini dumpers and a direct conversation about your equipment requirements.', 'domain' => 'bobliftloader.com', 'url' => ''],
];
?>
<section class="bl-page-hero bl-shell">
  <?php bl_breadcrumbs([['label' => 'Our company']]); ?>
  <div class="bl-page-heading"><div><p class="bl-eyebrow">OUR COMPANY / XUZHOU, CHINA</p><h1>ONE BOB-LIFT.<br><span class="bl-blue-text">MORE POSSIBILITIES.</span></h1></div><p>Xuzhou BOB-LIFT Construction Machinery Co., Ltd. builds lifting and compact equipment in Jiangsu, China. This site is its compact equipment business.</p></div>
</section>
<figure class="bl-company-hero"><picture><source media="(min-width: 801px)" srcset="<?= bl_escape(bl_asset('images/company/boblift-workshop-aerial.webp')) ?>"><img src="<?= bl_escape(bl_asset('images/company/boblift-workshop-aerial-mobile.webp')) ?>" alt="Aerial view inside the BOB-LIFT assembly workshop in Xuzhou, with crane booms lined up for final assembly" width="2560" height="1440" fetchpriority="high"></picture><figcaption>BOB-LIFT assembly workshop, Xuzhou · photograph from the main company website</figcaption></figure>
<section class="bl-company-facts bl-shell" aria-label="Company facts">
  <?php foreach ($companyFacts as $fact): ?><div><strong><?= bl_escape($fact['value']) ?><?php if ($fact['unit']): ?><span><?= bl_escape($fact['unit']) ?></span><?php endif; ?></strong><p><?= bl_escape($fact['label']) ?></p></div><?php endforeach; ?>
</section>
<section class="bl-company-story bl-shell">
  <div><p class="bl-eyebrow">THE COMPANY BEHIND THE MACHINES</p><h2>BUILT IN XUZHOU.<br>WORKING<br>WORLDWIDE.</h2></div>
  <div class="bl-prose"><?php $customCompany = bl_is_wordpress() ? bl_page_editor_content() : ''; if ($customCompany): ?><?= wp_kses_post($customCompany) ?><?php else: ?><p class="bl-lead"><strong>Xuzhou BOB-LIFT Construction Machinery Co., Ltd. is a high-tech enterprise specialising in the design, development, manufacture and sale of truck-mounted cranes, with a factory of over 37,000 square metres in Xuzhou, Jiangsu.</strong></p><p>BOB-LIFT was among the first Chinese manufacturers to obtain the national truck-mounted crane type-test manufacturing licence and ISO 9001 certification, and among the first to gain CE certification for exports to the European Union. Its products are designed through long-running technical cooperation with crane manufacturers in Italy and Sweden.</p><p>The company’s equipment is exported to more than 200 countries and regions, with established markets in Asia, the Americas, Europe and Africa, including over 200 cranes delivered to Russia.</p><p>bobliftloader.com is BOB-LIFT’s dedicated compact equipment business: mini skid steer loaders and mini dumpers, presented in one place with published specifications and a direct line to the team.</p><?php endif; ?><a class="bl-button bl-button-blue" href="https://www.boblift.com/aboutus.html" target="_blank" rel="noopener">Full company profile on boblift.com <?= bl_icon('arrow-up-right') ?></a></div>
</section>
<section class="bl-certificates bl-shell" aria-labelledby="certificates-title">
  <div class="bl-small-section-heading"><div><p class="bl-eyebrow">QUALITY & COMPLIANCE</p><h2 id="certificates-title">CERTIFIED TO EXPORT.</h2></div><p class="bl-compare-note">Certificates published by BOB-LIFT on the main company website. Request current copies with your enquiry.</p></div>
  <ul class="bl-certificate-strip"><?php foreach ($certificates as $cert): ?><li><img src="<?= bl_escape(bl_asset('images/company/' . $cert['file'] . '.webp')) ?>" alt="<?= bl_escape($cert['label']) ?>" width="452" height="640" loading="lazy"><span><?= bl_escape($cert['label']) ?></span></li><?php endforeach; ?></ul>
</section>
<section class="bl-brand-connection bl-shell"><p class="bl-eyebrow">ONE COMPANY. THREE WEBSITES.</p><div class="bl-connection-grid bl-connection-three"><?php foreach ($sites as $site): ?><?php if ($site['url']): ?><a href="<?= bl_escape($site['url']) ?>" target="_blank" rel="noopener"><?php else: ?><div class="bl-connection-current"><?php endif; ?><span><?= $site['index'] ?> / <?= $site['eyebrow'] ?></span><h3><?= $site['title'] ?></h3><p><?= $site['text'] ?></p><strong><?= $site['domain'] ?> <?= $site['url'] ? bl_icon('arrow-up-right') : '<small>YOU ARE HERE</small>' ?></strong><?= $site['url'] ? '</a>' : '</div>' ?><?php endforeach; ?></div></section>
<section class="bl-company-values bl-shell"><div><span>01</span><h3>Made in our own factory.</h3><p>Compact equipment and cranes are built at the BOB-LIFT plant in Xuzhou, with quality management certified to ISO 9001.</p></div><div><span>02</span><h3>Export-ready documentation.</h3><p>CE and EAC certification, published specifications and product literature to support customs, financing and tender requirements.</p></div><div><span>03</span><h3>One team for the whole fleet.</h3><p>The same company supports your loader, dumper or crane. Contact us about equipment, parts, service or dealer cooperation.</p></div></section>
<?php require __DIR__ . '/../partials/page-cta.php'; ?>
