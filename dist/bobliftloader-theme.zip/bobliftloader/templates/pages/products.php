<?php
$category = $route['category'];
$search = bl_query('q');
$load = bl_query('load');
$products = array_values(array_filter(bl_products(), static function (array $p) use ($category, $search, $load): bool {
    if ($category && $p['category'] !== $category) return false;
    if ($search && stripos($p['name'] . ' ' . $p['model'], $search) === false) return false;
    if ($load === 'small' && (!$p['load'] || $p['load'] > 2000)) return false;
    if ($load === 'large' && $p['load'] < 3000) return false;
    return true;
}));
$heading = $category === 'mini-dumpers' ? 'KEEP MATERIALS<br>MOVING.' : ($category === 'skid-steer-loaders' ? 'COMPACT SIZE.<br>MORE CAPABILITY.' : 'FIND YOUR<br>NEXT MACHINE.');
?>
<section class="bl-page-hero bl-shell">
  <?php bl_breadcrumbs($category ? [['label' => 'Equipment', 'url' => bl_url('/products/')], ['label' => $category === 'mini-dumpers' ? 'Mini dumpers' : 'Skid steer loaders']] : [['label' => 'Equipment']]); ?>
  <div class="bl-page-heading"><div><p class="bl-eyebrow">THE BOB-LIFT EQUIPMENT RANGE</p><h1><?= $heading ?></h1></div><p><?= $category === 'mini-dumpers' ? 'Published capacities. Real models. Find the mini dumper that fits your material transport requirements.' : 'Start with the work ahead. Explore our compact equipment, then get into the details.' ?></p></div>
</section>
<section class="bl-catalog bl-shell" aria-label="Product catalogue">
  <nav class="bl-category-nav" aria-label="Equipment categories"><?php foreach (['' => 'All equipment', 'skid-steer-loaders' => 'Skid steer loaders', 'mini-dumpers' => 'Mini dumpers'] as $key => $label): ?><a href="<?= bl_escape(bl_url('/products/' . ($key ? $key . '/' : ''))) ?>" <?= $category === $key ? 'aria-current="page"' : '' ?>><?= $label ?></a><?php endforeach; ?></nav>
  <form class="bl-catalog-tools" method="get" action="<?= bl_escape(bl_url($route['path'])) ?>"><label>Find a model<input type="search" name="q" value="<?= bl_escape($search) ?>" placeholder="Search model or product name"></label><?php if ($category !== 'skid-steer-loaders'): ?><label>Rated load<select name="load"><option value="">All capacities</option><option value="small" <?= $load === 'small' ? 'selected' : '' ?>>Up to 2,000 kg</option><option value="large" <?= $load === 'large' ? 'selected' : '' ?>>3,000 kg and above</option></select></label><?php endif; ?><button class="bl-button bl-button-blue" type="submit">Find equipment <?= bl_icon('arrow-up-right') ?></button><p><?= count($products) ?> <?= count($products) === 1 ? 'result' : 'results' ?></p></form>
  <?php if ($products): ?><div class="bl-product-grid"><?php foreach ($products as $product) bl_product_card($product); ?></div><?php else: ?><div class="bl-empty"><h2>No matching equipment.</h2><p>Try another model name or remove the capacity filter.</p><a class="bl-text-link" href="<?= bl_escape(bl_url($route['path'])) ?>">Clear filters <?= bl_icon('arrow-up-right') ?></a></div><?php endif; ?>
</section>
<?php if ($category !== 'skid-steer-loaders' && !$search && !$load) require __DIR__ . '/../partials/compare-table.php'; ?>
<?php require __DIR__ . '/../partials/page-cta.php'; ?>
