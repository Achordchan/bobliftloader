<?php $cardSpecs = $product['category'] === 'mini-dumpers' ? ['Rated load' => $product['specs']['Rated load'] ?? '—', 'Bucket' => $product['specs']['Bucket capacity'] ?? '—', 'Power' => $product['specs']['Engine power'] ?? '—'] : ['Running gear' => $product['specs']['Running gear'] ?? '—', 'Controls' => $product['specs']['Controls'] ?? '—', 'Spec sheet' => 'On request']; ?>
<article class="bl-product-card">
  <a class="bl-product-card-image" href="<?= bl_escape(bl_product_url($product)) ?>"><?php if ($product['image']): ?><img src="<?= bl_escape($product['image']) ?>" alt="<?= bl_escape($product['name']) ?>" width="800" height="650" loading="lazy"><?php else: ?><span class="bl-product-image-empty">Product photography will be added soon.</span><?php endif; ?><span class="bl-product-card-model"><?= bl_escape($product['model']) ?></span><span class="bl-card-arrow"><?= bl_icon('arrow-up-right') ?></span></a>
  <div class="bl-product-card-content"><p class="bl-eyebrow"><?= $product['category'] === 'mini-dumpers' ? 'MINI DUMPER' : 'SKID STEER LOADER' ?></p><h2><a href="<?= bl_escape(bl_product_url($product)) ?>"><?= bl_escape($product['name']) ?></a></h2>
    <dl><?php foreach ($cardSpecs as $label => $value): ?><div><dt><?= $label ?></dt><dd><?= bl_escape($value) ?></dd></div><?php endforeach; ?></dl>
  </div>
</article>
