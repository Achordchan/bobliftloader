<?php
/** Side-by-side published figures for every mini dumper; loaders join once their technical sheets are confirmed. */
$compareRows = ['Rated load', 'Bucket capacity', 'Engine power', 'Standard dimensions', 'Dimensions with roof / cab', 'Operating voltage', 'Minimum ground clearance'];
$compareProducts = array_values(array_filter(bl_products(), static fn($p) => $p['category'] === 'mini-dumpers' && $p['specs']));
usort($compareProducts, static fn($a, $b) => ($a['load'] ?? 0) <=> ($b['load'] ?? 0));
if ($compareProducts): ?>
<section class="bl-compare bl-shell" id="compare" aria-labelledby="compare-title">
  <div class="bl-small-section-heading"><div><p class="bl-eyebrow">PUBLISHED FIGURES / MINI DUMPERS</p><h2 id="compare-title">COMPARE THE RANGE.</h2></div><p class="bl-compare-note">Figures transcribed from the BOB-LIFT product pages. Confirm the final configuration with our team before ordering.</p></div>
  <div class="bl-compare-scroll"><table class="bl-compare-table"><thead><tr><th scope="col">Model</th><?php foreach ($compareProducts as $p): ?><th scope="col"><a href="<?= bl_escape(bl_product_url($p)) ?>"><img src="<?= bl_escape($p['image']) ?>" alt="" width="200" height="200" loading="lazy"><span><?= bl_escape($p['model']) ?></span><small><?= bl_escape($p['name']) ?></small></a></th><?php endforeach; ?></tr></thead><tbody><?php foreach ($compareRows as $row): ?><tr><th scope="row"><?= $row ?></th><?php foreach ($compareProducts as $p): ?><td><?= bl_escape($p['specs'][$row] ?? '—') ?></td><?php endforeach; ?></tr><?php endforeach; ?><tr class="bl-compare-actions"><th scope="row"><span class="bl-visually-hidden">Enquire</span></th><?php foreach ($compareProducts as $p): ?><td><a class="bl-text-link" href="<?= bl_escape(bl_contact_url($p)) ?>">Quote <?= bl_icon('arrow-up-right') ?></a></td><?php endforeach; ?></tr></tbody></table></div>
</section>
<?php endif; ?>
